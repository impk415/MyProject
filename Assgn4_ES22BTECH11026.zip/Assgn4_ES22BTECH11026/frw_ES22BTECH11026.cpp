#include<iostream>
#include<bits/stdc++.h>
#include<pthread.h>
#include<chrono>
#include<fstream>        //for file I/O
#include<unistd.h>
#include<random>         //to generate a random no. with exponential distribution
#include<thread>
#include<semaphore.h>    //since we use semaphores

using namespace std;
using namespace chrono;

int nw, nr, kw, kr, uCS, uRem; //Declaring input parameters
ofstream logFile;   //File which outputs log of all the events
ofstream avg_times_file;  //File which outputs the average times & the worst case time to access the CS for each of the threads

double readers_time_array[20][20];    //2D array. arr[i][j] stores the time taken by the ith reader thread to access the CS in the jth iteration
double writers_time_array[20][20];    //2D array. arr[i][j] stores the time taken by the ith writer thread to access the CS in the jth iteration

pthread_mutex_t file_lock = PTHREAD_MUTEX_INITIALIZER;   //lock variable which guards the file output CS

int readers_count = 0;   //keeps a count of the no. of readers in the CS
sem_t serviceQueue;     //TO assure fairness, keeps a record of the requests in the form of a queue
sem_t rmutex;           //to guard the entry section(namely incrementing the variable readers_count)
sem_t resourceLock;     //lock which guards the main CS(i.e. reading and writing from/to database etc.)


//function initialises all the semaphores to 1.
void sem_t_init(sem_t &serviceQueue, sem_t &rmutex, sem_t &resourceLock){
    sem_init(&serviceQueue, 0, 1);
    sem_init(&rmutex, 0, 1);
    sem_init(&resourceLock, 0, 1);
    return;
}

//function generates delay values exponentially distributed with an average of μCS, μRem milli-seconds.
double generateExponential(double average) {
    average /= 1000;   //converting to milliseconds
    static std::mt19937 gen(std::chrono::system_clock::now().time_since_epoch().count());
    return std::exponential_distribution<double>(1.0 / average)(gen);
}

//Function returns a string representing the current system time (alongwith date, month, & year)
char* getSysTime() {
    auto end = std::chrono::system_clock::now();
    time_t end_time = std::chrono::system_clock::to_time_t(end);
    return ctime(&end_time);
}

//Writer Function(DETAILED EXPLANATION IN REPORT)
void* writer(void* arg)
{   
    int thread_id = *(int*)arg;    //THREAD_id required to keep record of the log of the events(i.e. which thread enters the CS in which iteration)
    for (int i = 0; i < kw; i++)
    {
        pthread_mutex_lock(&file_lock);
        char* reqTime = getSysTime();
        auto start = chrono::steady_clock::now();     //timer starts recording the CS request  
        logFile << "CS request "<<i<<" by Writer Thread "<< thread_id <<" at "<< reqTime << endl;
        pthread_mutex_unlock(&file_lock);
       

        sem_wait(&serviceQueue);    //CS request, wait in queue to be serviced
        sem_wait(&resourceLock);    //grabs the resourceLock when at the front if the queue
        sem_post(&serviceQueue);    //Let next threads to be serviced

        //entry into the CS
        pthread_mutex_lock(&file_lock);
        char* enterTime = getSysTime();
        auto end = chrono::steady_clock::now();    //timer ends recording the CS entry
        logFile << "CS entry "<<i<<" by Writer Thread "<< thread_id <<" at "<< reqTime << endl;
        pthread_mutex_unlock(&file_lock);
        
        //store the time taken to enter the CS in the respective array
        std::chrono::duration<double> duration = end - start;
        double iteration_time = duration.count();
        writers_time_array[thread_id][i] = iteration_time * 1000.000;

        sleep(generateExponential(uCS)); // simulate a thread writing in CS

        //exiting the CS
        pthread_mutex_lock(&file_lock);
        char* exitTime = getSysTime();
        logFile << "CS exit "<<i<<" by Writer Thread "<< thread_id <<" at "<< reqTime << endl;
        pthread_mutex_unlock(&file_lock);

        sem_post(&resourceLock);   //release the resourceLock for other threads

        sleep(generateExponential(uRem)); // simulate a thread executing in Remainder Section
    }
    return NULL;
}

//Reader Function(DETAILED EXPLANATION IN REPORT)
void* reader(void* arg)
{
    int thread_id = *(int*)arg;    //THREAD_id required to keep record of the log of the events(i.e. which thread enters the CS in which iteration)
    for (int i = 0; i < kr; i++)
    {
        pthread_mutex_lock(&file_lock);
        char* reqTime = getSysTime();
        auto start = chrono::steady_clock::now();   //timer starts recording the CS request
        logFile << "CS request "<<i<<" by Reader Thread "<< thread_id <<" at "<< reqTime << endl;
        pthread_mutex_unlock(&file_lock);
       
        sem_wait(&serviceQueue);    //Request to access CS, Wait in the queue to be serviced
        sem_wait(&rmutex);     //guards the entry section(i.e. readers_count variable)
        readers_count++;
        if(readers_count == 1){
            sem_wait(&resourceLock);    //if it's the first reader in CS, grab the resourceLock, more readers can come in
        }

        //Releasing it for ither threads
        sem_post(&serviceQueue);
        sem_post(&rmutex);

        pthread_mutex_lock(&file_lock);
        char* enterTime = getSysTime();
        auto end = chrono::steady_clock::now();    //timer ends recording the CS entry
        logFile << "CS entry "<<i<<" by Reader Thread "<< thread_id <<" at "<< reqTime << endl;
        pthread_mutex_unlock(&file_lock);
        
        //store the time taken to enter the CS in the respective array
        std::chrono::duration<double> duration = end - start;
        double iteration_time = duration.count();
        readers_time_array[thread_id][i] = iteration_time * 1000.00;

        sleep(generateExponential(uCS));  // simulate a thread reading from CS
        
        //EXIT FROM CS
        pthread_mutex_lock(&file_lock);
        char* exitTime = getSysTime();
        logFile << "CS exit "<<i<<" by Reader Thread "<< thread_id <<" at "<< reqTime << endl;
        pthread_mutex_unlock(&file_lock);
                
        sem_wait(&rmutex);   //guard the decrementing of readers_count(since it has exited from CS)
        readers_count--;
        if(readers_count == 0){
            sem_post(&resourceLock);  //if it's the last reader, release the resourceLock for the writers(if any)
        }
        sem_post(&rmutex);

        sleep(generateExponential(uRem)); // simulate a thread executing in Remainder Section
    }
    return NULL;
}

int main(){
    //File Input
    ifstream inFile;
    inFile.open("inp_params.txt");
    if(inFile.fail()){
        cout<<"Error opening the file"<<endl;
    }
    inFile>>nw>>nr>>kw>>kr>>uCS>>uRem;
    inFile.close();

    logFile.open("FairRW-log.txt");
    if(logFile.fail()){
        cout<<"Error opening the file"<<endl;
    }

    avg_times_file.open("Average_time_Fair_RW.txt");
    if(avg_times_file.fail()){
        cout<<"Error opening the file"<<endl;
    }

    //Function call to initialise the semaphore values
    sem_t_init(serviceQueue, rmutex, resourceLock);

    //Alloating space for n array of pthread_t type in heap for each of the threads
    pthread_t* thread_ptr1 = new pthread_t[nr];
    pthread_t* thread_ptr2 = new pthread_t[nw];

    //arrays which store the integer ID's of the threads namely 0,1,2....
    int reader_id[nr];
    int writer_id[nw];

    //Creation of nr reader threads
    for(int i = 0; i < nr; i++){
        reader_id[i] = i;
        if(pthread_create(thread_ptr1 + i, NULL, reader, &reader_id[i])){
            cout<<"Error in creating the thread "<<i<<endl;
        }
    }
    //Creation of nw writer threads
    for(int i = 0; i < nw; i++){
        writer_id[i] = i;
        if(pthread_create(thread_ptr2 + i, NULL, writer, &writer_id[i])){
            cout<<"Error in creating the thread "<<i<<endl;
        }
    }
    //Joining all nr threads
    for(int i = 0; i < nr; i++){
        if(pthread_join(thread_ptr1[i], NULL)){
            cout<<"Error in joining the threads "<<i<<endl;
        }
    }
    //Joining all nw threads
    for(int i = 0; i < nw; i++){
        if(pthread_join(thread_ptr2[i], NULL)){
            cout<<"Error in joining the threads "<<i<<endl;
        }
    }

    //Function of these variables is evident from their names
    double total_writer_time = 0, total_reader_time = 0, writer_worst_case_time = 0.0, reader_worst_case_time = 0.0;
    
    //Summing up the times taken for each iteration for each of the nw writer threads.
    for(int i = 0; i < nw; i++){
        for(int j = 0; j < kw; j++){
            total_writer_time += writers_time_array[i][j];
            if(writers_time_array[i][j] > writer_worst_case_time){
                writer_worst_case_time = writers_time_array[i][j];
            }
        }
    }

    //Summing up the times taken for each iteration for each of the nw writer threads.
    for(int i = 0; i < nr; i++){
        for(int j = 0; j < kr; j++){
            total_reader_time += readers_time_array[i][j];
            if(readers_time_array[i][j] > reader_worst_case_time){
                reader_worst_case_time = readers_time_array[i][j];
            }
        }
    }

    //Calcuating the average
    double avg_writer_time = total_writer_time/(nw*kw);
    double avg_reader_time = total_reader_time/(nr*kr);

    avg_times_file<<"Average time for writer thread is: "<<avg_writer_time<<" ms"<<endl;
    avg_times_file<<"Average time for reader thread is: "<<avg_reader_time<<" ms"<<endl;
    avg_times_file<<"Worst Case time for writer thread is: "<<writer_worst_case_time<<" ms"<<endl;
    avg_times_file<<"Worst Case time for reader thread is: "<<reader_worst_case_time<<" ms"<<endl;
    logFile.close();
    avg_times_file.close();

    //destroying the semaphores after usage is completed.
    sem_destroy(&rmutex);
    sem_destroy(&resourceLock);
    sem_destroy(&serviceQueue);
return 0;
}