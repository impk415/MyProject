Hello.

Firstly, you should open the file named "inp_params.txt". Give input as follows:
nw nr kw kr uCS uRem


eg. 10 10 10 10 10 5


Then open any of the programs, and run the code. For the "rw_ES22BTECH11026.cpp", 2 output files would be opened after running the code- namely:

"RW-log.txt"  ---> stores the log events  =for each of threads  for writers_preference()
"Average_time_RW.txt"   ----> stores the avg times, worst case-times to enter the CS for each reader,writer threads   for writers_preference()


For the "frw_ES22BTECH11026.cpp", 2 output files would be opened after running the code- namely:

"FairRW-log.txt"  ---> stores the log events  =for each of threads  for fair_reader_writers()
"Average_time_Fair_RW.txt"   ----> stores the avg times, worst case-times to enter the CS for each reader,writer threads for fair_readers_writers()